# WarBerryPi

### Description
WarBerryPi was built to be used as a hardware implant during red teaming scenarios where we want to obtain as much information as possible in a short period of time with being as stealth as possible. Just find a network port and plug it in. The scripts have been designed in a way that the approach is targeted to avoid noise in the network that could lead to detection and to be as efficient as possible. The WarBerry script is a collection of scanning tools put together to provide that functionality.

### Categories
* Red Teaming
* Hardware Implant

### Black Hat sessions

 [![Black Hat Arsenal USA ](https://www.toolswatch.org/badges/arsenal/2016.svg)](https://www.toolswatch.org/2016/06/the-black-hat-arsenal-usa-2016-remarkable-line-up/)
[![Black Hat Europe](https://www.toolswatch.org/badges/arsenal/2016.svg)](https://www.toolswatch.org/2016/09/the-black-hat-arsenal-europe-2016-line-up/)

### Popularity

[![ToolsWatch Best Tools](https://www.toolswatch.org/badges/toptools/2016.svg)](https://www.toolswatch.org/2017/02/2016-top-security-tools-as-voted-by-toolswatch-org-readers/)
 
### Code 
https://github.com/secgroundzero/warberry

### Main developer
 Yiannis Ioannides - https://github.com/secgroundzero/warberry

### Social Media 
* [Twitter](https://twitter.com/sec_groundzero)
