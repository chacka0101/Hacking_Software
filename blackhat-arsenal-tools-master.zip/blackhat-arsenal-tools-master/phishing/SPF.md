# SPF - SpeedPhishing Framework 

### Description
SPF (SpeedPhish Framework) is a python tool designed to allow for quick recon and deployment of simple social engineering phishing exercises.

### Categories
* Phishing
* Frameworks

### Black Hat sessions
[![Arsenal](https://www.toolswatch.org/badges/arsenal/2015.svg)](https://www.toolswatch.org/2015/06/black-hat-arsenal-usa-2015-speakers-lineup/)

### Code 
https://github.com/tatanus/SPF

### Main developer
Adam Compton - https://github.com/tatanus

### Social Media 
* [Twitter](https://twitter.com/tatanus)
