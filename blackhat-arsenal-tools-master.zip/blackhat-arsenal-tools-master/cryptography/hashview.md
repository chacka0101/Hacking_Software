# Hashview

### Description
Hashview is a web front-end to hashcat with many powerful features geared towards penetration testers. Leverage task automation and real-time analytics for increased results and fancy reports.

### Categories
* Cryptography
* Penetration Testing
* Reporting

### Black Hat sessions
[![Hashview](https://rawgit.com/toolswatch/badges/master/arsenal/2017.svg)](https://www.blackhat.com/us-17/arsenal/schedule/#hashview-8019)
 
### Code 
https://github.com/hashview/hashview

### Main developers
 * Hans lakhan - i128 https://github.com/i128
 * Casey Cammilleri - ccammilleri https://github.com/ccammilleri

### Social Media 
* [@jarsnah12](https://twitter.com/jarsnah12)
* [@caseycammilleri](https://twitter.com/CaseyCammilleri)
* [http://www.hashview.io](https://www.hashview.io/) 
